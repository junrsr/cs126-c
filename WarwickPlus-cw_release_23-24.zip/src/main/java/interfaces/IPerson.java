package interfaces;

public interface IPerson {
    public int getID();
    public String getName();
    public String getProfilePath();
}
